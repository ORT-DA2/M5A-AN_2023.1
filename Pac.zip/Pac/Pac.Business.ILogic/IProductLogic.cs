﻿using Pac.Domain.Entities;

namespace Pac.Business.ILogic;
public interface IProductLogic
{
    Product GetProductById(string token, int id);
    Product GetProductByName(string name);
    Brand GetBrandByProduct(int productId);
    string CreateProduct(Product product);

}

