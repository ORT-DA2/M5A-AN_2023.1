﻿using Pac.Business.ILogic;
using Pac.Domain.Entities;

namespace Pac.Business.Logic;

public class ProductLogic : IProductLogic
{
    IEnumerable<Brand> brands;
    public ProductLogic()
    {
        brands = new List<Brand>();

        // Crear algunas marcas
        Brand brand1 = new Brand { Id = 1, Name = "Nike" };
        Brand brand2 = new Brand { Id = 2, Name = "Adidas" };
        Brand brand3 = new Brand { Id = 3, Name = "Puma" };
        Brand brand4 = new Brand { Id = 4, Name = "Reebok" };
        Brand brand5 = new Brand { Id = 5, Name = "New Balance" };

        // Crear algunos productos
        Product product1 = new Product { Id = 1, Name = "Air Max 90", Brand = brand1 };
        Product product2 = new Product { Id = 2, Name = "Ultraboost", Brand = brand2 };
        Product product3 = new Product { Id = 3, Name = "RS-X3", Brand = brand3 };
        Product product4 = new Product { Id = 4, Name = "Classic Leather", Brand = brand4 };
        Product product5 = new Product { Id = 5, Name = "990v5", Brand = brand5 };

        // Agregar los productos a cada marca
        brand1.Products = new List<Product> { product1 };
        brand2.Products = new List<Product> { product2 };
        brand3.Products = new List<Product> { product3 };
        brand4.Products = new List<Product> { product4 };
        brand5.Products = new List<Product> { product5 };

        // Agregar las marcas a la lista
        brands = brands.Append(brand1);
        brands = brands.Append(brand2);
        brands = brands.Append(brand3);
        brands = brands.Append(brand4);
        brands = brands.Append(brand5);
    }

    public string CreateProduct(Product product)
    {
        if (product.Id == 10 && product.Name == "Las propias bases")
            return "Producto ingresado correctamente";
        return "";
    }

    public Brand GetBrandByProduct(int productId)
    {
        Brand brand = brands.Where(u => u.Products.Any(l => l.Id == productId)).First();
        brand.Products = null;
        return brand;
    }


    public Product GetProductById(string token, int id)
    {
        if (token != "ac1dd90e-22da-49ab-8978-335e3a848761")
            return null;

        Product product = brands.Where(u => u.Products.Any(l => l.Id == id)).First().Products.First();
        product.Brand = null;
        return product;

    }

    public Product GetProductByName(string name)
    {
        Product product = brands.Where(u => u.Products.Any(l => l.Name == name)).First().Products.First();
        product.Brand = null;
        return product;
    }
}

