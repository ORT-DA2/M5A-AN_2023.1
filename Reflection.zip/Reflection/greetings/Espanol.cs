﻿namespace greetings
{
    public class Espanol
    {
        public string Saludar()
        {
            return "Hola Chicos";
        }

    }
}