﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace greetings
{
    public class English
    {
        public string Saludar()
        {
            return "Hello Guys";
        }

    }
}
