﻿
using System.Diagnostics.Metrics;
using System.IO;
using System.Reflection;

string rutaImporters = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
DirectoryInfo directory = new DirectoryInfo(rutaImporters);
FileInfo[] files = directory.GetFiles("*.dll");
Assembly myAssembly = Assembly.LoadFile(files[0].FullName);
foreach (var type in myAssembly.GetTypes())
{
    if (!type.IsPublic)
    {
        continue;
    }

    MemberInfo[] members = type.GetMembers(BindingFlags.Public
                                          | BindingFlags.Instance
                                          | BindingFlags.InvokeMethod);
    foreach (MemberInfo member in members)
    {
        Console.WriteLine(type.Name + "." + member.Name);
        //instance is needed to invoke the method
        object classInstance = Activator.CreateInstance(type, null);
        MethodInfo methodInfo = type.GetMethod(member.Name);
        Console.WriteLine(methodInfo.Invoke(classInstance, null));
    }
}

Console.WriteLine(files.Length);